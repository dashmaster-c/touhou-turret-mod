package touhouturretMod.core;

import mindustry.mod.Mod;

public class ModTemplate extends Mod{

    @Override
    public void init(){
    }

    @Override
    public void loadContent(){
    }
}
